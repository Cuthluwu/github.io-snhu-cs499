package edu.snhu.cs499.service;

import java.util.Date;
import java.util.List;

import edu.snhu.cs499.model.Appointment;
import edu.snhu.cs499.repository.InMemoryRecordRepository;
import edu.snhu.cs499.repository.RecordRepository;
import edu.snhu.cs499.validation.ValidationRules;

/**
 * Coordinates appointment operations and keeps direct repository state hidden
 * from callers.
 */
public final class AppointmentService {
    private final RecordRepository<Appointment> appointments =
            new InMemoryRecordRepository<>("appointment");

    public void addAppointment(Appointment appointment) {
        Appointment safeCopy = ValidationRules.requiredObject(
                appointment, "Appointment").copy();
        appointments.add(safeCopy.getAppointmentId(), safeCopy);
    }

    public void deleteAppointment(String appointmentId) {
        appointments.delete(normalizeId(appointmentId));
    }

    public void updateAppointmentDate(String appointmentId, Date appointmentDate) {
        getStoredAppointment(appointmentId).setAppointmentDate(appointmentDate);
    }

    public void updateDescription(String appointmentId, String description) {
        getStoredAppointment(appointmentId).setDescription(description);
    }

    public Appointment getAppointment(String appointmentId) {
        return getStoredAppointment(appointmentId).copy();
    }

    public List<Appointment> getAllAppointments() {
        return appointments.snapshot().stream().map(Appointment::copy).toList();
    }

    public int getAppointmentCount() {
        return appointments.size();
    }

    private Appointment getStoredAppointment(String appointmentId) {
        return appointments.getRequired(normalizeId(appointmentId));
    }

    private String normalizeId(String appointmentId) {
        return ValidationRules.requiredText(
                appointmentId, "Appointment ID", Appointment.MAX_ID_LENGTH);
    }
}
