package edu.snhu.cs499.model;

import java.time.Clock;
import java.util.Date;
import java.util.Objects;

import edu.snhu.cs499.validation.ValidationRules;

/**
 * Represents one appointment. Date values are defensively copied to prevent
 * callers from changing the stored date without validation.
 */
public final class Appointment {
    public static final int MAX_ID_LENGTH = 10;
    public static final int MAX_DESCRIPTION_LENGTH = 50;

    private final String appointmentId;
    private final Clock clock;
    private Date appointmentDate;
    private String description;

    public Appointment(String appointmentId, Date appointmentDate, String description) {
        this(appointmentId, appointmentDate, description, Clock.systemDefaultZone());
    }

    Appointment(String appointmentId, Date appointmentDate, String description, Clock clock) {
        this.clock = Objects.requireNonNull(clock, "clock cannot be null");
        this.appointmentId = ValidationRules.requiredText(
                appointmentId, "Appointment ID", MAX_ID_LENGTH);
        this.appointmentDate = ValidationRules.futureDate(
                appointmentDate, "Appointment date", clock);
        this.description = ValidationRules.requiredText(
                description, "Description", MAX_DESCRIPTION_LENGTH);
    }

    public String getAppointmentId() {
        return appointmentId;
    }

    public Date getAppointmentDate() {
        return new Date(appointmentDate.getTime());
    }

    public String getDescription() {
        return description;
    }

    public void setAppointmentDate(Date appointmentDate) {
        this.appointmentDate = ValidationRules.futureDate(
                appointmentDate, "Appointment date", clock);
    }

    public void setDescription(String description) {
        this.description = ValidationRules.requiredText(
                description, "Description", MAX_DESCRIPTION_LENGTH);
    }

    public Appointment copy() {
        return new Appointment(appointmentId, appointmentDate, description, clock);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof Appointment appointment)) {
            return false;
        }
        return appointmentId.equals(appointment.appointmentId)
                && appointmentDate.equals(appointment.appointmentDate)
                && description.equals(appointment.description);
    }

    @Override
    public int hashCode() {
        return Objects.hash(appointmentId, appointmentDate, description);
    }

    @Override
    public String toString() {
        return "Appointment{id='" + appointmentId + "', date=" + appointmentDate + "}";
    }
}
