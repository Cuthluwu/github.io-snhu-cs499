package edu.snhu.cs499.service;

import java.util.List;

import edu.snhu.cs499.model.Contact;
import edu.snhu.cs499.repository.InMemoryRecordRepository;
import edu.snhu.cs499.repository.RecordRepository;
import edu.snhu.cs499.validation.ValidationRules;

/**
 * Coordinates validated contact operations while preventing callers from
 * directly changing the objects held by the repository.
 */
public final class ContactService {
    private final RecordRepository<Contact> contacts =
            new InMemoryRecordRepository<>("contact");

    public void addContact(Contact contact) {
        Contact safeCopy = ValidationRules.requiredObject(contact, "Contact").copy();
        contacts.add(safeCopy.getContactId(), safeCopy);
    }

    public void deleteContact(String contactId) {
        contacts.delete(normalizeId(contactId));
    }

    public void updateFirstName(String contactId, String firstName) {
        getStoredContact(contactId).setFirstName(firstName);
    }

    public void updateLastName(String contactId, String lastName) {
        getStoredContact(contactId).setLastName(lastName);
    }

    public void updatePhone(String contactId, String phone) {
        getStoredContact(contactId).setPhone(phone);
    }

    public void updateAddress(String contactId, String address) {
        getStoredContact(contactId).setAddress(address);
    }

    /**
     * Returns a defensive copy and uses one consistent not-found policy.
     */
    public Contact getContact(String contactId) {
        return getStoredContact(contactId).copy();
    }

    /**
     * Returns an unmodifiable snapshot of defensive copies.
     */
    public List<Contact> getAllContacts() {
        return contacts.snapshot().stream().map(Contact::copy).toList();
    }

    public int getContactCount() {
        return contacts.size();
    }

    private Contact getStoredContact(String contactId) {
        return contacts.getRequired(normalizeId(contactId));
    }

    private String normalizeId(String contactId) {
        return ValidationRules.requiredText(contactId, "Contact ID", Contact.MAX_ID_LENGTH);
    }
}
