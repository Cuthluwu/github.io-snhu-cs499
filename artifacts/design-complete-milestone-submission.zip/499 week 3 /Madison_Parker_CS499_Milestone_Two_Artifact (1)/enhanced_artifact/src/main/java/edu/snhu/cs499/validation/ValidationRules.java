package edu.snhu.cs499.validation;

import java.time.Clock;
import java.util.Date;
import java.util.Objects;
import java.util.regex.Pattern;

import edu.snhu.cs499.exception.ValidationException;

/**
 * Shared validation helpers used by the model and service layers.
 */
public final class ValidationRules {
    private static final Pattern TEN_DIGIT_PHONE = Pattern.compile("\\d{10}");

    private ValidationRules() {
        // Utility class.
    }

    /**
     * Trims and validates a required text value.
     *
     * @param value the value to validate
     * @param fieldName the user-facing field name used in an error message
     * @param maximumLength the largest accepted length after trimming
     * @return the trimmed value
     * @throws ValidationException when the value is null, blank, or too long
     */
    public static String requiredText(String value, String fieldName, int maximumLength) {
        if (maximumLength < 1) {
            throw new IllegalArgumentException("Maximum length must be positive.");
        }
        if (value == null) {
            throw new ValidationException(fieldName + " is required.");
        }

        String normalized = value.trim();
        if (normalized.isEmpty()) {
            throw new ValidationException(fieldName + " cannot be blank.");
        }
        if (normalized.length() > maximumLength) {
            throw new ValidationException(
                    fieldName + " cannot be longer than " + maximumLength + " characters.");
        }
        return normalized;
    }

    /**
     * Validates and returns a ten-digit phone number.
     */
    public static String tenDigitPhone(String value, String fieldName) {
        String normalized = requiredText(value, fieldName, 10);
        if (!TEN_DIGIT_PHONE.matcher(normalized).matches()) {
            throw new ValidationException(fieldName + " must contain exactly 10 digits.");
        }
        return normalized;
    }

    /**
     * Validates that a date exists and is not earlier than the supplied clock.
     * A defensive copy is returned so callers cannot retain the model's state.
     */
    public static Date futureDate(Date value, String fieldName, Clock clock) {
        Objects.requireNonNull(clock, "clock cannot be null");
        if (value == null) {
            throw new ValidationException(fieldName + " is required.");
        }

        Date currentTime = Date.from(clock.instant());
        if (value.before(currentTime)) {
            throw new ValidationException(fieldName + " cannot be in the past.");
        }
        return new Date(value.getTime());
    }

    /**
     * Validates that an object supplied to a service is not null.
     */
    public static <T> T requiredObject(T value, String fieldName) {
        if (value == null) {
            throw new ValidationException(fieldName + " is required.");
        }
        return value;
    }
}
