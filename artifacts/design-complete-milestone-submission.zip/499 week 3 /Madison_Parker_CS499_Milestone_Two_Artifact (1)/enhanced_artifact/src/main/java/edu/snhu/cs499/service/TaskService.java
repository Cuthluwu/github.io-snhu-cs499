package edu.snhu.cs499.service;

import java.util.List;

import edu.snhu.cs499.model.Task;
import edu.snhu.cs499.repository.InMemoryRecordRepository;
import edu.snhu.cs499.repository.RecordRepository;
import edu.snhu.cs499.validation.ValidationRules;

/**
 * Coordinates task creation, retrieval, updates, and deletion through a
 * consistent repository contract.
 */
public final class TaskService {
    private final RecordRepository<Task> tasks =
            new InMemoryRecordRepository<>("task");

    public void addTask(Task task) {
        Task safeCopy = ValidationRules.requiredObject(task, "Task").copy();
        tasks.add(safeCopy.getTaskId(), safeCopy);
    }

    public void deleteTask(String taskId) {
        tasks.delete(normalizeId(taskId));
    }

    public void updateName(String taskId, String name) {
        getStoredTask(taskId).setName(name);
    }

    public void updateDescription(String taskId, String description) {
        getStoredTask(taskId).setDescription(description);
    }

    public Task getTask(String taskId) {
        return getStoredTask(taskId).copy();
    }

    public List<Task> getAllTasks() {
        return tasks.snapshot().stream().map(Task::copy).toList();
    }

    public int getTaskCount() {
        return tasks.size();
    }

    private Task getStoredTask(String taskId) {
        return tasks.getRequired(normalizeId(taskId));
    }

    private String normalizeId(String taskId) {
        return ValidationRules.requiredText(taskId, "Task ID", Task.MAX_ID_LENGTH);
    }
}
