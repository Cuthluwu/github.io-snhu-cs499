package edu.snhu.cs499.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import edu.snhu.cs499.exception.DuplicateRecordException;
import edu.snhu.cs499.exception.RecordNotFoundException;
import edu.snhu.cs499.model.Contact;

class ContactServiceTest {
    private ContactService service;

    @BeforeEach
    void setUp() {
        service = new ContactService();
    }

    private Contact contact(String id) {
        return new Contact(id, "Madison", "Parker", "2075550123", "Bangor");
    }

    @Test
    void addStoresACopyInsteadOfTheCallersObject() {
        Contact original = contact("C100");
        service.addContact(original);

        original.setAddress("Orono");

        assertEquals("Bangor", service.getContact("C100").getAddress());
    }

    @Test
    void getReturnsACopyInsteadOfRepositoryState() {
        service.addContact(contact("C101"));

        Contact returned = service.getContact("C101");
        returned.setFirstName("Changed");

        assertEquals("Madison", service.getContact("C101").getFirstName());
    }

    @Test
    void duplicateAndMissingRecordsUseSpecificExceptions() {
        service.addContact(contact("C102"));

        assertThrows(DuplicateRecordException.class, () -> service.addContact(contact("C102")));
        assertThrows(RecordNotFoundException.class, () -> service.getContact("MISSING"));
        assertThrows(RecordNotFoundException.class, () -> service.deleteContact("MISSING"));
    }

    @Test
    void serviceUpdatesRemainValidated() {
        service.addContact(contact("C103"));

        service.updateAddress("C103", " Orono ");

        assertEquals("Orono", service.getContact("C103").getAddress());
    }

    @Test
    void snapshotsCannotBeStructurallyModified() {
        service.addContact(contact("C104"));
        List<Contact> snapshot = service.getAllContacts();

        assertThrows(UnsupportedOperationException.class,
                () -> snapshot.add(contact("C105")));
        assertEquals(1, service.getContactCount());
    }
}
