package edu.snhu.cs499.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;

import edu.snhu.cs499.exception.DuplicateRecordException;
import edu.snhu.cs499.exception.RecordNotFoundException;
import edu.snhu.cs499.model.Task;

class TaskServiceTest {
    private Task task(String id) {
        return new Task(id, "Read rubric", "Review the milestone requirements.");
    }

    @Test
    void taskCrudUsesAConsistentContract() {
        TaskService service = new TaskService();
        service.addTask(task("T100"));

        service.updateName("T100", "Enhance code");
        service.updateDescription("T100", "Refactor and test the service layer.");

        Task result = service.getTask("T100");
        assertEquals("Enhance code", result.getName());
        assertEquals("Refactor and test the service layer.", result.getDescription());

        service.deleteTask("T100");
        assertEquals(0, service.getTaskCount());
        assertThrows(RecordNotFoundException.class, () -> service.getTask("T100"));
    }

    @Test
    void duplicateIdsUseTheSharedExceptionPolicy() {
        TaskService service = new TaskService();
        service.addTask(task("T101"));

        assertThrows(DuplicateRecordException.class, () -> service.addTask(task("T101")));
    }

    @Test
    void returnedTasksDoNotExposeInternalState() {
        TaskService service = new TaskService();
        service.addTask(task("T102"));

        Task returned = service.getTask("T102");
        returned.setName("External change");

        assertEquals("Read rubric", service.getTask("T102").getName());
    }
}
