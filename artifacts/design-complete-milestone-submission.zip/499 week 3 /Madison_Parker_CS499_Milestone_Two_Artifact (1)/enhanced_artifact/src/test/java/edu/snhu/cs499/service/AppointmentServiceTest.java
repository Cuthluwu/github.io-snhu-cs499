package edu.snhu.cs499.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.Calendar;
import java.util.Date;

import org.junit.jupiter.api.Test;

import edu.snhu.cs499.exception.DuplicateRecordException;
import edu.snhu.cs499.exception.RecordNotFoundException;
import edu.snhu.cs499.model.Appointment;

class AppointmentServiceTest {
    private Date daysFromToday(int days) {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_YEAR, days);
        return calendar.getTime();
    }

    private Appointment appointment(String id) {
        return new Appointment(id, daysFromToday(5), "Project review");
    }

    @Test
    void appointmentServiceSupportsExplicitUpdates() {
        AppointmentService service = new AppointmentService();
        service.addAppointment(appointment("A100"));

        Date newDate = daysFromToday(10);
        service.updateAppointmentDate("A100", newDate);
        service.updateDescription("A100", "Final project review");

        Appointment result = service.getAppointment("A100");
        assertEquals(newDate, result.getAppointmentDate());
        assertEquals("Final project review", result.getDescription());
    }

    @Test
    void appointmentServiceUsesSharedExceptions() {
        AppointmentService service = new AppointmentService();
        service.addAppointment(appointment("A101"));

        assertThrows(DuplicateRecordException.class,
                () -> service.addAppointment(appointment("A101")));
        assertThrows(RecordNotFoundException.class,
                () -> service.deleteAppointment("MISSING"));
    }

    @Test
    void returnedAppointmentsDoNotExposeStoredState() {
        AppointmentService service = new AppointmentService();
        service.addAppointment(appointment("A102"));

        Appointment returned = service.getAppointment("A102");
        returned.setDescription("External change");

        assertEquals("Project review", service.getAppointment("A102").getDescription());
    }
}
