package edu.snhu.cs499.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.Date;

import org.junit.jupiter.api.Test;

import edu.snhu.cs499.exception.ValidationException;

class AppointmentTest {
    private static final Clock FIXED_CLOCK =
            Clock.fixed(Instant.parse("2026-07-13T12:00:00Z"), ZoneOffset.UTC);

    private Date minutesFromClock(long minutes) {
        return Date.from(FIXED_CLOCK.instant().plusSeconds(minutes * 60));
    }

    @Test
    void constructorUsesDeterministicDateValidation() {
        Appointment appointment = new Appointment(
                "A100", minutesFromClock(30), "Planning meeting", FIXED_CLOCK);

        assertEquals("A100", appointment.getAppointmentId());
        assertEquals(minutesFromClock(30), appointment.getAppointmentDate());
    }

    @Test
    void pastDatesAndBlankDescriptionsAreRejected() {
        assertThrows(ValidationException.class,
                () -> new Appointment("A101", minutesFromClock(-1), "Meeting", FIXED_CLOCK));
        assertThrows(ValidationException.class,
                () -> new Appointment("A101", minutesFromClock(10), " ", FIXED_CLOCK));
    }

    @Test
    void dateGetterAndConstructorUseDefensiveCopies() {
        Date suppliedDate = minutesFromClock(45);
        Appointment appointment = new Appointment("A102", suppliedDate, "Review", FIXED_CLOCK);

        suppliedDate.setTime(0);
        assertNotEquals(suppliedDate, appointment.getAppointmentDate());

        Date returnedDate = appointment.getAppointmentDate();
        returnedDate.setTime(0);
        assertEquals(minutesFromClock(45), appointment.getAppointmentDate());
    }

    @Test
    void updatesUseTheSameRules() {
        Appointment appointment = new Appointment(
                "A103", minutesFromClock(20), "Original", FIXED_CLOCK);

        appointment.setAppointmentDate(minutesFromClock(60));
        appointment.setDescription(" Updated ");

        assertEquals(minutesFromClock(60), appointment.getAppointmentDate());
        assertEquals("Updated", appointment.getDescription());
        assertThrows(ValidationException.class,
                () -> appointment.setAppointmentDate(minutesFromClock(-5)));
    }
}
