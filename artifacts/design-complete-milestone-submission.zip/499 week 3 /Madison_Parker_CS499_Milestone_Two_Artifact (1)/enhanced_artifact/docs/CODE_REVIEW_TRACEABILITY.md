# Code Review Finding to Enhancement Traceability

| Code review finding | Completed enhancement | Main files |
|---|---|---|
| Classes had no package structure. | Added model, service, repository, validation, and exception packages. | `src/main/java/edu/snhu/cs499/` |
| Numeric limits were repeated as magic numbers. | Added named length constants to each model. | `Contact.java`, `Task.java`, `Appointment.java` |
| Required strings allowed empty or whitespace-only data. | Added shared trimming and blank-value validation. | `ValidationRules.java` |
| `get` returned `null`, while update/delete threw general exceptions. | Standardized missing-record behavior with `RecordNotFoundException`. | repositories and services |
| Duplicate and missing failures both used `IllegalArgumentException`. | Added focused exception types. | `exception/` |
| Services repeated duplicate, lookup, delete, and count behavior. | Added a small repository interface and HashMap implementation. | `RecordRepository.java`, `InMemoryRecordRepository.java` |
| Returned mutable objects exposed internal service state. | Services store copies, return copies, and provide unmodifiable snapshots. | models and services |
| Appointment changes could bypass the service. | Added date and description update methods to `AppointmentService`. | `AppointmentService.java` |
| Tests did not cover blanks, copy protection, or API consistency. | Added JUnit tests for these cases and a standalone smoke test. | `src/test/`, `src/testSupport/` |
| Comments did not fully explain public contracts. | Added focused JavaDoc and project documentation. | source files and `README.md` |

## Course outcome connection

- **Outcome 2:** The narrative, JavaDoc, README, and traceability document present the work clearly to technical and nontechnical readers.
- **Outcome 4:** The package structure, repository contract, validation utility, custom exceptions, tests, Git-ready layout, and Maven configuration demonstrate professional software engineering practices.
- **Outcome 5:** Blank-input rejection, defensive copying, protected snapshots, consistent failures, and validation at creation and update points reduce opportunities for invalid or unintended state changes.
