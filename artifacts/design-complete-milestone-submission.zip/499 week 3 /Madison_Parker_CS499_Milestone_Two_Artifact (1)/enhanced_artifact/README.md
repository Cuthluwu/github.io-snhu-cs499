# CS 499 Software Design and Engineering Enhancement

This project enhances the CS 320 Contact, Task, and Appointment services. The original project correctly implemented the required model objects, in-memory services, validation, and JUnit tests. The enhancement keeps that functionality while making the project easier to understand, test, and extend.

## Main improvements

1. Organized the code into `model`, `service`, `repository`, `validation`, and `exception` packages.
2. Replaced repeated numeric limits with named constants.
3. Added one shared validation utility that trims required text and rejects blank values.
4. Added specific exceptions for validation failures, duplicate IDs, and missing records.
5. Introduced a small repository interface for the operations genuinely shared by all three services.
6. Standardized service behavior so missing records no longer return `null` in one method and throw an exception in another.
7. Stored and returned defensive copies so callers cannot silently change repository state.
8. Returned unmodifiable snapshots for collection results.
9. Added explicit appointment update operations through the service layer.
10. Expanded tests for blank input, normalization, exception consistency, defensive copies, and protected snapshots.
11. Added JavaDoc, equality methods, `toString`, Maven configuration, and a dependency-free smoke test.

## Project layout

```text
src/main/java/edu/snhu/cs499/
  exception/   custom failure types
  model/       Contact, Task, Appointment
  repository/  shared repository contract and HashMap implementation
  service/     record-specific application operations
  validation/  shared validation rules

src/test/java/edu/snhu/cs499/
  model/       JUnit 5 model tests
  service/     JUnit 5 service tests

src/testSupport/java/edu/snhu/cs499/
  ServiceLayerSmokeTest.java
```

## Run the JUnit tests

```bash
mvn test
```

## Dependency-free verification

```bash
mkdir -p build/classes
javac -Xlint:all -d build/classes $(find src/main/java -name "*.java")
javac -Xlint:all -cp build/classes -d build/classes \
  $(find src/testSupport/java -name "*.java")
java -cp build/classes edu.snhu.cs499.ServiceLayerSmokeTest
```

Expected result:

```text
All enhanced service-layer smoke tests passed.
```

## Scope boundary

Search, filtering, sorting, and complexity analysis are intentionally reserved for the Algorithms and Data Structures enhancement. This milestone focuses on architecture, consistency, validation, documentation, testing, and secure handling of mutable state.
