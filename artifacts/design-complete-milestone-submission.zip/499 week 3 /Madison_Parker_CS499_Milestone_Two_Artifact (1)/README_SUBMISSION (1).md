CS 499 Milestone Two Submission

Name: Madison Parker   
Artifact:CS 320 Contact, Task, and Appointment Service Suite

Submission contents

- `original_artifact/` contains the unmodified CS 320 project files created in May 2026, including the original Java classes, JUnit tests, reflection, and original archive.
- `enhanced_artifact/` contains the redesigned Java service-layer project, expanded tests, Maven configuration, documentation, and verification results.
- `Madison_Parker_CS499_Milestone_Two_Narrative.docx` is the required accompanying narrative.

Artifact choice

The Module One plan initially considered the CS 250 SNHU Travel planning artifact for this category. During the code review, the CS 320 service suite provided stronger code-level evidence for software design and engineering, so it became the primary technical artifact for this milestone. The enhancement follows the specific findings and plans stated in the code review.

Verification

The enhanced production code was compiled with Java 21 using `javac -Xlint:all`. A dependency-free smoke test exercised validation, CRUD behavior, custom exceptions, defensive copies, and protected result collections. The test completed successfully. The included Maven configuration can be used to run the full JUnit 5 test suite with `mvn test` in an environment with Maven installed.
