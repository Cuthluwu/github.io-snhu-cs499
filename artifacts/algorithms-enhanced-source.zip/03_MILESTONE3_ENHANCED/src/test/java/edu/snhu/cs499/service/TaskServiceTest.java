package edu.snhu.cs499.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.List;

import org.junit.jupiter.api.Test;

import edu.snhu.cs499.exception.DuplicateRecordException;
import edu.snhu.cs499.exception.RecordNotFoundException;
import edu.snhu.cs499.exception.ValidationException;
import edu.snhu.cs499.model.Task;

class TaskServiceTest {
    private Task task(String id) {
        return new Task(id, "Read rubric", "Review the milestone requirements.");
    }

    @Test
    void taskCrudUsesAConsistentContract() {
        TaskService service = new TaskService();
        service.addTask(task("T100"));

        service.updateName("T100", "Enhance code");
        service.updateDescription("T100", "Refactor and test the service layer.");

        Task result = service.getTask("T100");
        assertEquals("Enhance code", result.getName());
        assertEquals("Refactor and test the service layer.", result.getDescription());

        service.deleteTask("T100");
        assertEquals(0, service.getTaskCount());
        assertThrows(RecordNotFoundException.class, () -> service.getTask("T100"));
    }

    @Test
    void duplicateIdsUseTheSharedExceptionPolicy() {
        TaskService service = new TaskService();
        service.addTask(task("T101"));

        assertThrows(DuplicateRecordException.class, () -> service.addTask(task("T101")));
    }

    @Test
    void returnedTasksDoNotExposeInternalState() {
        TaskService service = new TaskService();
        service.addTask(task("T102"));

        Task returned = service.getTask("T102");
        returned.setName("External change");

        assertEquals("Read rubric", service.getTask("T102").getName());
    }

    @Test
    void keywordSearchChecksNameAndDescriptionWithoutCaseSensitivity() {
        TaskService service = new TaskService();
        service.addTask(new Task("T203", "Write report", "Summarize ALGORITHM results."));
        service.addTask(new Task("T201", "Algorithm review", "Check complexity."));
        service.addTask(new Task("T202", "Database work", "Create indexes."));

        List<Task> matches = service.searchTasks("algorithm");

        assertEquals(List.of("T201", "T203"),
                matches.stream().map(Task::getTaskId).toList());
    }

    @Test
    void searchOrderingUsesNameThenIdAsATieBreaker() {
        TaskService service = new TaskService();
        service.addTask(new Task("T303", "Review", "Third matching item"));
        service.addTask(new Task("T301", "Analyze", "First matching item"));
        service.addTask(new Task("T302", "Review", "Second matching item"));

        List<Task> matches = service.searchTasks("matching");

        assertEquals(List.of("T301", "T302", "T303"),
                matches.stream().map(Task::getTaskId).toList());
    }

    @Test
    void searchHandlesEmptyMapAndNoMatches() {
        TaskService service = new TaskService();
        assertEquals(List.of(), service.searchTasks("test"));

        service.addTask(task("T401"));
        assertEquals(List.of(), service.searchTasks("unrelated"));
    }

    @Test
    void searchRejectsNullAndBlankKeywords() {
        TaskService service = new TaskService();

        assertThrows(ValidationException.class, () -> service.searchTasks(null));
        assertThrows(ValidationException.class, () -> service.searchTasks("  "));
    }

    @Test
    void searchResultsCannotModifyStoredTasksOrListStructure() {
        TaskService service = new TaskService();
        service.addTask(task("T501"));
        List<Task> results = service.searchTasks("rubric");

        assertThrows(UnsupportedOperationException.class,
                () -> results.add(task("T502")));
        results.get(0).setName("External change");

        assertEquals("Read rubric", service.getTask("T501").getName());
    }
}
