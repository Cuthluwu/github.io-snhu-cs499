package edu.snhu.cs499.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import edu.snhu.cs499.exception.DuplicateRecordException;
import edu.snhu.cs499.exception.RecordNotFoundException;
import edu.snhu.cs499.exception.ValidationException;
import edu.snhu.cs499.model.Contact;

class ContactServiceTest {
    private ContactService service;

    @BeforeEach
    void setUp() {
        service = new ContactService();
    }

    private Contact contact(String id) {
        return new Contact(id, "Madison", "Parker", "2075550123", "Bangor");
    }

    @Test
    void addStoresACopyInsteadOfTheCallersObject() {
        Contact original = contact("C100");
        service.addContact(original);

        original.setAddress("Orono");

        assertEquals("Bangor", service.getContact("C100").getAddress());
    }

    @Test
    void getReturnsACopyInsteadOfRepositoryState() {
        service.addContact(contact("C101"));

        Contact returned = service.getContact("C101");
        returned.setFirstName("Changed");

        assertEquals("Madison", service.getContact("C101").getFirstName());
    }

    @Test
    void duplicateAndMissingRecordsUseSpecificExceptions() {
        service.addContact(contact("C102"));

        assertThrows(DuplicateRecordException.class, () -> service.addContact(contact("C102")));
        assertThrows(RecordNotFoundException.class, () -> service.getContact("MISSING"));
        assertThrows(RecordNotFoundException.class, () -> service.deleteContact("MISSING"));
    }

    @Test
    void serviceUpdatesRemainValidated() {
        service.addContact(contact("C103"));

        service.updateAddress("C103", " Orono ");

        assertEquals("Orono", service.getContact("C103").getAddress());
    }

    @Test
    void snapshotsCannotBeStructurallyModified() {
        service.addContact(contact("C104"));
        List<Contact> snapshot = service.getAllContacts();

        assertThrows(UnsupportedOperationException.class,
                () -> snapshot.add(contact("C105")));
        assertEquals(1, service.getContactCount());
    }

    @Test
    void keywordSearchIsCaseInsensitiveAndDeterministicallySorted() {
        service.addContact(new Contact("C203", "Zoe", "Parker", "2075550199", "Portland"));
        service.addContact(new Contact("C201", "Amy", "Parker", "2075550101", "Bangor"));
        service.addContact(new Contact("C202", "Ben", "Adams", "2075550102", "Bangor"));

        List<Contact> matches = service.searchContacts("BANGOR");

        assertEquals(List.of("C202", "C201"),
                matches.stream().map(Contact::getContactId).toList());
    }

    @Test
    void lastNameSearchSupportsSubstringsAndStableOrdering() {
        service.addContact(new Contact("C303", "Zoe", "Parker", "2075550199", "Portland"));
        service.addContact(new Contact("C301", "Amy", "Parker", "2075550101", "Bangor"));
        service.addContact(new Contact("C302", "Ben", "Park", "2075550102", "Bangor"));

        List<Contact> matches = service.searchByLastName("park");

        assertEquals(List.of("C302", "C301", "C303"),
                matches.stream().map(Contact::getContactId).toList());
    }

    @Test
    void searchHandlesEmptyAndNoMatchResults() {
        assertEquals(List.of(), service.searchContacts("anything"));

        service.addContact(contact("C401"));
        assertEquals(List.of(), service.searchContacts("not present"));
    }

    @Test
    void searchRejectsMissingCriteria() {
        assertThrows(ValidationException.class, () -> service.searchContacts(null));
        assertThrows(ValidationException.class, () -> service.searchContacts("   "));
        assertThrows(ValidationException.class, () -> service.searchByLastName(" "));
    }

    @Test
    void searchResultsAreUnmodifiableDefensiveCopies() {
        service.addContact(contact("C501"));
        List<Contact> results = service.searchContacts("parker");

        assertThrows(UnsupportedOperationException.class,
                () -> results.add(contact("C502")));
        results.get(0).setAddress("External change");

        assertEquals("Bangor", service.getContact("C501").getAddress());
    }
}
