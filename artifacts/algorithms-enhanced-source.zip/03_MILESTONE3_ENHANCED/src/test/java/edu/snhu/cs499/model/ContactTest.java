package edu.snhu.cs499.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;

import edu.snhu.cs499.exception.ValidationException;

class ContactTest {
    @Test
    void constructorTrimsRequiredText() {
        Contact contact = new Contact(" C100 ", " Madison ", " Parker ", "2075550123", " Bangor ");

        assertEquals("C100", contact.getContactId());
        assertEquals("Madison", contact.getFirstName());
        assertEquals("Parker", contact.getLastName());
        assertEquals("Bangor", contact.getAddress());
    }

    @Test
    void constructorRejectsBlankRequiredFields() {
        assertThrows(ValidationException.class,
                () -> new Contact(" ", "Madison", "Parker", "2075550123", "Bangor"));
        assertThrows(ValidationException.class,
                () -> new Contact("C101", " ", "Parker", "2075550123", "Bangor"));
        assertThrows(ValidationException.class,
                () -> new Contact("C101", "Madison", " ", "2075550123", "Bangor"));
        assertThrows(ValidationException.class,
                () -> new Contact("C101", "Madison", "Parker", "2075550123", " "));
    }

    @Test
    void phoneMustContainExactlyTenDigits() {
        assertThrows(ValidationException.class,
                () -> new Contact("C102", "Madison", "Parker", "207-555-0123", "Bangor"));
        assertThrows(ValidationException.class,
                () -> new Contact("C102", "Madison", "Parker", "123456789", "Bangor"));
    }

    @Test
    void boundaryLengthsAreAccepted() {
        Contact contact = new Contact(
                "1234567890",
                "1234567890",
                "abcdefghij",
                "2075550123",
                "123456789012345678901234567890");

        assertEquals(10, contact.getContactId().length());
        assertEquals(30, contact.getAddress().length());
    }

    @Test
    void updatesUseTheSameValidationRules() {
        Contact contact = new Contact("C103", "Madison", "Parker", "2075550123", "Bangor");

        contact.setAddress(" Orono ");
        assertEquals("Orono", contact.getAddress());
        assertThrows(ValidationException.class, () -> contact.setFirstName("   "));
        assertThrows(ValidationException.class, () -> contact.setPhone("bad phone"));
    }
}
