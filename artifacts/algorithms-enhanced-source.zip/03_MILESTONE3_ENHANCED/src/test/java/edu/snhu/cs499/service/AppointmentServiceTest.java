package edu.snhu.cs499.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.time.Instant;
import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;

import edu.snhu.cs499.exception.DuplicateRecordException;
import edu.snhu.cs499.exception.RecordNotFoundException;
import edu.snhu.cs499.exception.ValidationException;
import edu.snhu.cs499.model.Appointment;

class AppointmentServiceTest {
    private Date date(String instant) {
        return Date.from(Instant.parse(instant));
    }

    private Appointment appointment(String id) {
        return new Appointment(id, date("2099-07-20T12:00:00Z"), "Project review");
    }

    @Test
    void appointmentServiceSupportsExplicitUpdates() {
        AppointmentService service = new AppointmentService();
        service.addAppointment(appointment("A100"));

        Date newDate = date("2099-07-25T12:00:00Z");
        service.updateAppointmentDate("A100", newDate);
        service.updateDescription("A100", "Final project review");

        Appointment result = service.getAppointment("A100");
        assertEquals(newDate, result.getAppointmentDate());
        assertEquals("Final project review", result.getDescription());
    }

    @Test
    void appointmentServiceUsesSharedExceptions() {
        AppointmentService service = new AppointmentService();
        service.addAppointment(appointment("A101"));

        assertThrows(DuplicateRecordException.class,
                () -> service.addAppointment(appointment("A101")));
        assertThrows(RecordNotFoundException.class,
                () -> service.deleteAppointment("MISSING"));
    }

    @Test
    void returnedAppointmentsDoNotExposeStoredState() {
        AppointmentService service = new AppointmentService();
        service.addAppointment(appointment("A102"));

        Appointment returned = service.getAppointment("A102");
        returned.setDescription("External change");

        assertEquals("Project review", service.getAppointment("A102").getDescription());
    }

    @Test
    void rangeSearchIncludesBothBoundariesAndSortsChronologically() {
        AppointmentService service = new AppointmentService();
        Date start = date("2099-08-01T09:00:00Z");
        Date middle = date("2099-08-02T09:00:00Z");
        Date end = date("2099-08-03T09:00:00Z");

        service.addAppointment(new Appointment("A203", end, "End"));
        service.addAppointment(new Appointment("A201", start, "Start"));
        service.addAppointment(new Appointment("A202", middle, "Middle"));

        List<Appointment> matches = service.findAppointmentsBetween(start, end);

        assertEquals(List.of("A201", "A202", "A203"),
                matches.stream().map(Appointment::getAppointmentId).toList());
    }

    @Test
    void rangeSearchUsesIdToBreakDateTies() {
        AppointmentService service = new AppointmentService();
        Date sharedDate = date("2099-09-01T12:00:00Z");
        service.addAppointment(new Appointment("A302", sharedDate, "Second"));
        service.addAppointment(new Appointment("A301", sharedDate, "First"));

        List<Appointment> matches = service.findAppointmentsBetween(sharedDate, sharedDate);

        assertEquals(List.of("A301", "A302"),
                matches.stream().map(Appointment::getAppointmentId).toList());
    }

    @Test
    void rangeSearchHandlesNoMatches() {
        AppointmentService service = new AppointmentService();
        service.addAppointment(appointment("A401"));

        List<Appointment> matches = service.findAppointmentsBetween(
                date("2099-01-01T00:00:00Z"), date("2099-01-02T00:00:00Z"));

        assertEquals(List.of(), matches);
    }

    @Test
    void rangeSearchRejectsMissingOrReversedDates() {
        AppointmentService service = new AppointmentService();
        Date early = date("2099-01-01T00:00:00Z");
        Date late = date("2099-01-02T00:00:00Z");

        assertThrows(ValidationException.class,
                () -> service.findAppointmentsBetween(null, late));
        assertThrows(ValidationException.class,
                () -> service.findAppointmentsBetween(early, null));
        assertThrows(ValidationException.class,
                () -> service.findAppointmentsBetween(late, early));
    }

    @Test
    void rangeResultsAreUnmodifiableDefensiveCopies() {
        AppointmentService service = new AppointmentService();
        Date appointmentDate = date("2099-10-01T12:00:00Z");
        service.addAppointment(new Appointment("A501", appointmentDate, "Original"));

        List<Appointment> matches = service.findAppointmentsBetween(
                date("2099-10-01T00:00:00Z"), date("2099-10-02T00:00:00Z"));

        assertThrows(UnsupportedOperationException.class,
                () -> matches.add(new Appointment(
                        "A502", date("2099-10-01T15:00:00Z"), "Added")));
        matches.get(0).setDescription("External change");

        assertEquals("Original", service.getAppointment("A501").getDescription());
    }
}
