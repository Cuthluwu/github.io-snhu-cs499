package edu.snhu.cs499.model;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;

import edu.snhu.cs499.exception.ValidationException;

class TaskTest {
    @Test
    void constructorNormalizesText() {
        Task task = new Task(" T100 ", " Write tests ", " Verify the service layer. ");

        assertEquals("T100", task.getTaskId());
        assertEquals("Write tests", task.getName());
        assertEquals("Verify the service layer.", task.getDescription());
    }

    @Test
    void blankValuesAreRejected() {
        assertThrows(ValidationException.class, () -> new Task(" ", "Name", "Description"));
        assertThrows(ValidationException.class, () -> new Task("T101", " ", "Description"));
        assertThrows(ValidationException.class, () -> new Task("T101", "Name", " "));
    }

    @Test
    void boundaryLengthsAreAccepted() {
        Task task = new Task(
                "1234567890",
                "12345678901234567890",
                "12345678901234567890123456789012345678901234567890");

        assertEquals(10, task.getTaskId().length());
        assertEquals(20, task.getName().length());
        assertEquals(50, task.getDescription().length());
    }

    @Test
    void updatesStillValidateAndTrim() {
        Task task = new Task("T102", "Old name", "Old description");

        task.setName(" New name ");
        task.setDescription(" New description ");

        assertEquals("New name", task.getName());
        assertEquals("New description", task.getDescription());
        assertThrows(ValidationException.class, () -> task.setName(" "));
    }
}
