package edu.snhu.cs499.model;

import java.time.Clock;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.Date;

/**
 * Verifies that copying a stored appointment does not fail after its scheduled
 * time has passed.
 */
public final class AppointmentCopySmokeTest {
    private AppointmentCopySmokeTest() {
    }

    public static void main(String[] args) {
        MutableClock clock = new MutableClock(
                Instant.parse("2026-07-13T12:00:00Z"), ZoneOffset.UTC);
        Date scheduledDate = Date.from(clock.instant().plusSeconds(60));
        Appointment appointment = new Appointment("A900", scheduledDate, "Review", clock);

        clock.advanceSeconds(120);
        Appointment copy = appointment.copy();

        if (!appointment.equals(copy) || !scheduledDate.equals(copy.getAppointmentDate())) {
            throw new AssertionError("Appointment copy did not preserve stored values.");
        }
        System.out.println("Appointment copy regression test passed: completed records remain readable.");
    }

    private static final class MutableClock extends Clock {
        private Instant currentInstant;
        private final ZoneId zone;

        private MutableClock(Instant currentInstant, ZoneId zone) {
            this.currentInstant = currentInstant;
            this.zone = zone;
        }

        private void advanceSeconds(long seconds) {
            currentInstant = currentInstant.plusSeconds(seconds);
        }

        @Override
        public ZoneId getZone() {
            return zone;
        }

        @Override
        public Clock withZone(ZoneId newZone) {
            return new MutableClock(currentInstant, newZone);
        }

        @Override
        public Instant instant() {
            return currentInstant;
        }
    }
}
