package edu.snhu.cs499;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import edu.snhu.cs499.exception.DuplicateRecordException;
import edu.snhu.cs499.exception.RecordNotFoundException;
import edu.snhu.cs499.exception.ValidationException;
import edu.snhu.cs499.model.Appointment;
import edu.snhu.cs499.model.Contact;
import edu.snhu.cs499.model.Task;
import edu.snhu.cs499.service.AppointmentService;
import edu.snhu.cs499.service.ContactService;
import edu.snhu.cs499.service.TaskService;

/**
 * Dependency-free verification used to compile and exercise the enhanced code
 * in environments where Maven/JUnit is unavailable.
 */
public final class ServiceLayerSmokeTest {
    private ServiceLayerSmokeTest() {
    }

    public static void main(String[] args) {
        verifyContactService();
        verifyTaskService();
        verifyAppointmentService();
        System.out.println("All enhanced service-layer smoke tests passed.");
    }

    private static void verifyContactService() {
        ContactService service = new ContactService();
        Contact original = new Contact(" C100 ", " Madison ", " Parker ", "2075550123", " Bangor ");
        service.addContact(original);
        original.setAddress("Orono");
        check("Bangor".equals(service.getContact("C100").getAddress()),
                "Contact add should store a defensive copy.");

        Contact returned = service.getContact("C100");
        returned.setFirstName("Changed");
        check("Madison".equals(service.getContact("C100").getFirstName()),
                "Contact get should return a defensive copy.");

        List<Contact> snapshot = service.getAllContacts();
        expect(UnsupportedOperationException.class,
                () -> snapshot.add(new Contact("C101", "Test", "User", "2075559999", "Bangor")));
        expect(DuplicateRecordException.class, () -> service.addContact(original));
        expect(RecordNotFoundException.class, () -> service.getContact("MISSING"));
        expect(ValidationException.class,
                () -> new Contact("C102", " ", "User", "2075559999", "Bangor"));
    }

    private static void verifyTaskService() {
        TaskService service = new TaskService();
        service.addTask(new Task("T100", "Read rubric", "Review project requirements."));
        service.updateName("T100", "Enhance code");
        check("Enhance code".equals(service.getTask("T100").getName()),
                "Task update should change stored state through the service.");
        service.deleteTask("T100");
        expect(RecordNotFoundException.class, () -> service.getTask("T100"));
    }

    private static void verifyAppointmentService() {
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DAY_OF_YEAR, 5);
        Date firstDate = calendar.getTime();

        AppointmentService service = new AppointmentService();
        service.addAppointment(new Appointment("A100", firstDate, "Review"));

        calendar.add(Calendar.DAY_OF_YEAR, 5);
        Date updatedDate = calendar.getTime();
        service.updateAppointmentDate("A100", updatedDate);
        service.updateDescription("A100", "Final review");

        Appointment returned = service.getAppointment("A100");
        check(updatedDate.equals(returned.getAppointmentDate()),
                "Appointment date update should be retained.");
        returned.getAppointmentDate().setTime(0);
        check(updatedDate.equals(service.getAppointment("A100").getAppointmentDate()),
                "Appointment date should be defensively copied.");
    }

    private static void check(boolean condition, String message) {
        if (!condition) {
            throw new AssertionError(message);
        }
    }

    private static void expect(Class<? extends Throwable> expected, Runnable operation) {
        try {
            operation.run();
        } catch (Throwable actual) {
            if (expected.isInstance(actual)) {
                return;
            }
            throw new AssertionError(
                    "Expected " + expected.getSimpleName() + " but received "
                            + actual.getClass().getSimpleName(), actual);
        }
        throw new AssertionError("Expected " + expected.getSimpleName() + " to be thrown.");
    }
}
