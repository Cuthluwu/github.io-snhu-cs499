package edu.snhu.cs499;

import java.time.Instant;
import java.util.Date;
import java.util.List;

import edu.snhu.cs499.exception.ValidationException;
import edu.snhu.cs499.model.Appointment;
import edu.snhu.cs499.model.Contact;
import edu.snhu.cs499.model.Task;
import edu.snhu.cs499.service.AppointmentService;
import edu.snhu.cs499.service.ContactService;
import edu.snhu.cs499.service.TaskService;

/**
 * Dependency-free verification for a computer that has Java but not Maven.
 */
public final class AlgorithmEnhancementSmokeTest {
    private static int checksCompleted;

    private AlgorithmEnhancementSmokeTest() {
    }

    public static void main(String[] args) {
        verifyContactSearch();
        verifyTaskSearch();
        verifyAppointmentRangeSearch();
        verifyInputValidation();
        System.out.println(
                "Algorithm enhancement smoke test passed: " + checksCompleted + " checks.");
    }

    private static void verifyContactSearch() {
        ContactService service = new ContactService();
        service.addContact(new Contact("C3", "Zoe", "Parker", "2075550103", "Portland"));
        service.addContact(new Contact("C1", "Amy", "Parker", "2075550101", "Bangor"));
        service.addContact(new Contact("C2", "Ben", "Adams", "2075550102", "Bangor"));
        service.addContact(new Contact("C4", "Amy", "Parker", "2075550104", "Augusta"));

        List<Contact> addressResults = service.searchContacts("BANGOR");
        check(addressResults.size() == 2, "Contact search should find both Bangor records.");
        check("C2".equals(addressResults.get(0).getContactId()),
                "Contact results should sort by last name.");
        check("C1".equals(addressResults.get(1).getContactId()),
                "The second contact result is out of order.");

        List<Contact> lastNameResults = service.searchByLastName("park");
        check(lastNameResults.size() == 3, "Last-name substring search should find three records.");
        check(List.of("C1", "C4", "C3").equals(
                        lastNameResults.stream().map(Contact::getContactId).toList()),
                "Contact tie-breakers should use first name and then ID.");

        addressResults.get(0).setAddress("Changed outside service");
        check("Bangor".equals(service.getContact("C2").getAddress()),
                "Contact search results must be defensive copies.");
        checkUnmodifiable(addressResults, "Contact result list must be unmodifiable.");
        check(service.searchContacts("not present").isEmpty(),
                "A contact search with no match should return an empty list.");
    }

    private static void verifyTaskSearch() {
        TaskService service = new TaskService();
        service.addTask(new Task("T3", "Write report", "Summarize algorithm results."));
        service.addTask(new Task("T1", "Algorithm review", "Check complexity."));
        service.addTask(new Task("T2", "Database work", "Create indexes."));
        service.addTask(new Task("T4", "Write report", "Second algorithm result."));

        List<Task> results = service.searchTasks("ALGORITHM");
        check(results.size() == 3, "Task search should inspect both names and descriptions.");
        check(List.of("T1", "T3", "T4").equals(
                        results.stream().map(Task::getTaskId).toList()),
                "Tasks should sort by name and then ID.");

        results.get(0).setName("Changed");
        check("Algorithm review".equals(service.getTask("T1").getName()),
                "Task search results must be defensive copies.");
        checkUnmodifiable(results, "Task result list must be unmodifiable.");
        check(service.searchTasks("no-match-value").isEmpty(),
                "A task search with no match should return an empty list.");
    }

    private static void verifyAppointmentRangeSearch() {
        AppointmentService service = new AppointmentService();
        Date start = date("2099-08-01T09:00:00Z");
        Date middle = date("2099-08-02T09:00:00Z");
        Date end = date("2099-08-03T09:00:00Z");
        service.addAppointment(new Appointment("A3", end, "End"));
        service.addAppointment(new Appointment("A1", start, "Start"));
        service.addAppointment(new Appointment("A4", middle, "Middle second"));
        service.addAppointment(new Appointment("A2", middle, "Middle first"));

        List<Appointment> results = service.findAppointmentsBetween(start, end);
        check(results.size() == 4, "Inclusive range should keep both boundaries.");
        check(List.of("A1", "A2", "A4", "A3").equals(
                        results.stream().map(Appointment::getAppointmentId).toList()),
                "Appointments should sort by date and then ID.");

        results.get(0).setDescription("Changed outside service");
        check("Start".equals(service.getAppointment("A1").getDescription()),
                "Appointment results must be defensive copies.");
        checkUnmodifiable(results, "Appointment result list must be unmodifiable.");

        List<Appointment> noMatches = service.findAppointmentsBetween(
                date("2099-09-01T00:00:00Z"), date("2099-09-02T00:00:00Z"));
        check(noMatches.isEmpty(), "An appointment range with no match should be empty.");
    }

    private static void verifyInputValidation() {
        TaskService tasks = new TaskService();
        checkThrowsValidation(() -> tasks.searchTasks(" "), "Blank task search must fail.");
        checkThrowsValidation(() -> tasks.searchTasks(null), "Null task search must fail.");

        ContactService contacts = new ContactService();
        checkThrowsValidation(() -> contacts.searchContacts(null),
                "Null contact search must fail.");
        checkThrowsValidation(() -> contacts.searchByLastName("   "),
                "Blank last-name search must fail.");

        AppointmentService appointments = new AppointmentService();
        checkThrowsValidation(
                () -> appointments.findAppointmentsBetween(
                        date("2099-02-02T00:00:00Z"), date("2099-02-01T00:00:00Z")),
                "Reversed date range must fail.");
        checkThrowsValidation(
                () -> appointments.findAppointmentsBetween(null, date("2099-02-01T00:00:00Z")),
                "Missing start date must fail.");
        checkThrowsValidation(
                () -> appointments.findAppointmentsBetween(date("2099-02-01T00:00:00Z"), null),
                "Missing end date must fail.");
    }

    private static Date date(String instant) {
        return Date.from(Instant.parse(instant));
    }

    private static void checkUnmodifiable(List<?> results, String message) {
        boolean thrown = false;
        try {
            results.clear();
        } catch (UnsupportedOperationException expected) {
            thrown = true;
        }
        check(thrown, message);
    }

    private static void checkThrowsValidation(Runnable action, String message) {
        boolean thrown = false;
        try {
            action.run();
        } catch (ValidationException expected) {
            thrown = true;
        }
        check(thrown, message);
    }

    private static void check(boolean condition, String message) {
        if (!condition) {
            throw new AssertionError(message);
        }
        checksCompleted++;
    }
}
