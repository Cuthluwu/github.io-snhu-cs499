package edu.snhu.cs499.model;

import java.util.Objects;

import edu.snhu.cs499.validation.ValidationRules;

/**
 * Represents one task with an immutable identifier and validated editable
 * fields.
 */
public final class Task {
    public static final int MAX_ID_LENGTH = 10;
    public static final int MAX_NAME_LENGTH = 20;
    public static final int MAX_DESCRIPTION_LENGTH = 50;

    private final String taskId;
    private String name;
    private String description;

    public Task(String taskId, String name, String description) {
        this.taskId = ValidationRules.requiredText(taskId, "Task ID", MAX_ID_LENGTH);
        this.name = ValidationRules.requiredText(name, "Task name", MAX_NAME_LENGTH);
        this.description = ValidationRules.requiredText(
                description, "Task description", MAX_DESCRIPTION_LENGTH);
    }

    public String getTaskId() {
        return taskId;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public void setName(String name) {
        this.name = ValidationRules.requiredText(name, "Task name", MAX_NAME_LENGTH);
    }

    public void setDescription(String description) {
        this.description = ValidationRules.requiredText(
                description, "Task description", MAX_DESCRIPTION_LENGTH);
    }

    public Task copy() {
        return new Task(taskId, name, description);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof Task task)) {
            return false;
        }
        return taskId.equals(task.taskId)
                && name.equals(task.name)
                && description.equals(task.description);
    }

    @Override
    public int hashCode() {
        return Objects.hash(taskId, name, description);
    }

    @Override
    public String toString() {
        return "Task{id='" + taskId + "', name='" + name + "'}";
    }
}
