package edu.snhu.cs499.service;

import java.util.ArrayList;
import java.util.List;

import edu.snhu.cs499.algorithm.RecordComparators;
import edu.snhu.cs499.model.Task;
import edu.snhu.cs499.repository.InMemoryRecordRepository;
import edu.snhu.cs499.repository.RecordRepository;
import edu.snhu.cs499.validation.ValidationRules;

/**
 * Coordinates task creation, retrieval, updates, deletion, and keyword search.
 */
public final class TaskService {
    private final RecordRepository<Task> tasks =
            new InMemoryRecordRepository<>("task");

    public void addTask(Task task) {
        Task safeCopy = ValidationRules.requiredObject(task, "Task").copy();
        tasks.add(safeCopy.getTaskId(), safeCopy);
    }

    public void deleteTask(String taskId) {
        tasks.delete(normalizeId(taskId));
    }

    public void updateName(String taskId, String name) {
        getStoredTask(taskId).setName(name);
    }

    public void updateDescription(String taskId, String description) {
        getStoredTask(taskId).setDescription(description);
    }

    public Task getTask(String taskId) {
        return getStoredTask(taskId).copy();
    }

    public List<Task> getAllTasks() {
        List<Task> copies = new ArrayList<>();
        for (Task task : tasks.snapshot()) {
            copies.add(task.copy());
        }
        return List.copyOf(copies);
    }

    /**
     * Scans task names and descriptions for a case-insensitive substring.
     * The scan is O(n), and sorting m matches is O(m log m).
     */
    public List<Task> searchTasks(String keyword) {
        String term = ValidationRules.requiredSearchTerm(keyword, "Task search keyword");
        List<Task> matches = new ArrayList<>();

        for (Task task : tasks.snapshot()) {
            if (contains(task.getName(), term) || contains(task.getDescription(), term)) {
                matches.add(task.copy());
            }
        }

        matches.sort(RecordComparators.TASK_BY_NAME_ID);
        return List.copyOf(matches);
    }

    public int getTaskCount() {
        return tasks.size();
    }

    private boolean contains(String value, String normalizedTerm) {
        return ValidationRules.searchableText(value).contains(normalizedTerm);
    }

    private Task getStoredTask(String taskId) {
        return tasks.getRequired(normalizeId(taskId));
    }

    private String normalizeId(String taskId) {
        return ValidationRules.requiredText(taskId, "Task ID", Task.MAX_ID_LENGTH);
    }
}
