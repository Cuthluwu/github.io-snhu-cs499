package edu.snhu.cs499.service;

import java.util.ArrayList;
import java.util.List;

import edu.snhu.cs499.algorithm.RecordComparators;
import edu.snhu.cs499.model.Contact;
import edu.snhu.cs499.repository.InMemoryRecordRepository;
import edu.snhu.cs499.repository.RecordRepository;
import edu.snhu.cs499.validation.ValidationRules;

/**
 * Coordinates validated contact operations while keeping repository objects private.
 */
public final class ContactService {
    private final RecordRepository<Contact> contacts =
            new InMemoryRecordRepository<>("contact");

    public void addContact(Contact contact) {
        Contact safeCopy = ValidationRules.requiredObject(contact, "Contact").copy();
        contacts.add(safeCopy.getContactId(), safeCopy);
    }

    public void deleteContact(String contactId) {
        contacts.delete(normalizeId(contactId));
    }

    public void updateFirstName(String contactId, String firstName) {
        getStoredContact(contactId).setFirstName(firstName);
    }

    public void updateLastName(String contactId, String lastName) {
        getStoredContact(contactId).setLastName(lastName);
    }

    public void updatePhone(String contactId, String phone) {
        getStoredContact(contactId).setPhone(phone);
    }

    public void updateAddress(String contactId, String address) {
        getStoredContact(contactId).setAddress(address);
    }

    public Contact getContact(String contactId) {
        return getStoredContact(contactId).copy();
    }

    public List<Contact> getAllContacts() {
        List<Contact> copies = new ArrayList<>();
        for (Contact contact : contacts.snapshot()) {
            copies.add(contact.copy());
        }
        return List.copyOf(copies);
    }

    /**
     * Scans every contact for a case-insensitive substring match in the ID,
     * first name, last name, phone number, or address. A scan is O(n). Sorting
     * m matches is O(m log m), where m is no greater than n.
     */
    public List<Contact> searchContacts(String keyword) {
        String term = ValidationRules.requiredSearchTerm(keyword, "Search keyword");
        List<Contact> matches = new ArrayList<>();

        for (Contact contact : contacts.snapshot()) {
            if (matchesContact(contact, term)) {
                matches.add(contact.copy());
            }
        }

        matches.sort(RecordComparators.CONTACT_BY_LAST_FIRST_ID);
        return List.copyOf(matches);
    }

    /**
     * Scans only the last-name field and returns a stable last-name, first-name,
     * and ID order.
     */
    public List<Contact> searchByLastName(String lastName) {
        String term = ValidationRules.requiredSearchTerm(lastName, "Last-name search");
        List<Contact> matches = new ArrayList<>();

        for (Contact contact : contacts.snapshot()) {
            if (contains(contact.getLastName(), term)) {
                matches.add(contact.copy());
            }
        }

        matches.sort(RecordComparators.CONTACT_BY_LAST_FIRST_ID);
        return List.copyOf(matches);
    }

    public int getContactCount() {
        return contacts.size();
    }

    private boolean matchesContact(Contact contact, String term) {
        return contains(contact.getContactId(), term)
                || contains(contact.getFirstName(), term)
                || contains(contact.getLastName(), term)
                || contains(contact.getPhone(), term)
                || contains(contact.getAddress(), term);
    }

    private boolean contains(String value, String normalizedTerm) {
        return ValidationRules.searchableText(value).contains(normalizedTerm);
    }

    private Contact getStoredContact(String contactId) {
        return contacts.getRequired(normalizeId(contactId));
    }

    private String normalizeId(String contactId) {
        return ValidationRules.requiredText(contactId, "Contact ID", Contact.MAX_ID_LENGTH);
    }
}
