package edu.snhu.cs499.algorithm;

import java.util.Comparator;

import edu.snhu.cs499.model.Appointment;
import edu.snhu.cs499.model.Contact;
import edu.snhu.cs499.model.Task;

/**
 * Ordering rules used after search and filtering operations.
 * The identifier is the final key so equal primary values still have a stable order.
 */
public final class RecordComparators {
    public static final Comparator<Contact> CONTACT_BY_LAST_FIRST_ID =
            Comparator.comparing(Contact::getLastName, String.CASE_INSENSITIVE_ORDER)
                    .thenComparing(Contact::getFirstName, String.CASE_INSENSITIVE_ORDER)
                    .thenComparing(Contact::getContactId);

    public static final Comparator<Task> TASK_BY_NAME_ID =
            Comparator.comparing(Task::getName, String.CASE_INSENSITIVE_ORDER)
                    .thenComparing(Task::getTaskId);

    public static final Comparator<Appointment> APPOINTMENT_BY_DATE_ID =
            Comparator.comparing(Appointment::getAppointmentDate)
                    .thenComparing(Appointment::getAppointmentId);

    private RecordComparators() {
        // Utility class.
    }
}
