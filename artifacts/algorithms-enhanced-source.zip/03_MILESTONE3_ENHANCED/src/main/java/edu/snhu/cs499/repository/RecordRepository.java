package edu.snhu.cs499.repository;

import java.util.List;

/**
 * Small repository contract for the operations shared by the three services.
 * Record-specific updates remain in each concrete service.
 */
public interface RecordRepository<T> {
    void add(String id, T record);

    T getRequired(String id);

    void delete(String id);

    int size();

    List<T> snapshot();
}
