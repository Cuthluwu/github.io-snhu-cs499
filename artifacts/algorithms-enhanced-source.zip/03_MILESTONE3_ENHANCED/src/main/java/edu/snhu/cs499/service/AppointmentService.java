package edu.snhu.cs499.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import edu.snhu.cs499.algorithm.RecordComparators;
import edu.snhu.cs499.model.Appointment;
import edu.snhu.cs499.repository.InMemoryRecordRepository;
import edu.snhu.cs499.repository.RecordRepository;
import edu.snhu.cs499.validation.ValidationRules;

/**
 * Coordinates appointment operations and keeps repository objects private.
 */
public final class AppointmentService {
    private final RecordRepository<Appointment> appointments =
            new InMemoryRecordRepository<>("appointment");

    public void addAppointment(Appointment appointment) {
        Appointment safeCopy = ValidationRules.requiredObject(
                appointment, "Appointment").copy();
        appointments.add(safeCopy.getAppointmentId(), safeCopy);
    }

    public void deleteAppointment(String appointmentId) {
        appointments.delete(normalizeId(appointmentId));
    }

    public void updateAppointmentDate(String appointmentId, Date appointmentDate) {
        getStoredAppointment(appointmentId).setAppointmentDate(appointmentDate);
    }

    public void updateDescription(String appointmentId, String description) {
        getStoredAppointment(appointmentId).setDescription(description);
    }

    public Appointment getAppointment(String appointmentId) {
        return getStoredAppointment(appointmentId).copy();
    }

    public List<Appointment> getAllAppointments() {
        List<Appointment> copies = new ArrayList<>();
        for (Appointment appointment : appointments.snapshot()) {
            copies.add(appointment.copy());
        }
        return List.copyOf(copies);
    }

    /**
     * Scans all appointments and keeps dates on or between the two boundaries.
     * The scan is O(n), and sorting m matches is O(m log m).
     */
    public List<Appointment> findAppointmentsBetween(
            Date startInclusive, Date endInclusive) {
        Date[] range = ValidationRules.inclusiveDateRange(startInclusive, endInclusive);
        long startTime = range[0].getTime();
        long endTime = range[1].getTime();
        List<Appointment> matches = new ArrayList<>();

        for (Appointment appointment : appointments.snapshot()) {
            long appointmentTime = appointment.getAppointmentDate().getTime();
            if (appointmentTime >= startTime && appointmentTime <= endTime) {
                matches.add(appointment.copy());
            }
        }

        matches.sort(RecordComparators.APPOINTMENT_BY_DATE_ID);
        return List.copyOf(matches);
    }

    public int getAppointmentCount() {
        return appointments.size();
    }

    private Appointment getStoredAppointment(String appointmentId) {
        return appointments.getRequired(normalizeId(appointmentId));
    }

    private String normalizeId(String appointmentId) {
        return ValidationRules.requiredText(
                appointmentId, "Appointment ID", Appointment.MAX_ID_LENGTH);
    }
}
