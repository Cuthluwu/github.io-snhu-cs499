package edu.snhu.cs499.exception;

/**
 * Indicates that a service already contains a record with the requested ID.
 */
public final class DuplicateRecordException extends IllegalArgumentException {
    private static final long serialVersionUID = 1L;

    public DuplicateRecordException(String recordType, String id) {
        super(String.format("A %s with ID '%s' already exists.", recordType, id));
    }
}
