package edu.snhu.cs499.exception;

/**
 * Indicates that a requested service record could not be found.
 */
public final class RecordNotFoundException extends IllegalArgumentException {
    private static final long serialVersionUID = 1L;

    public RecordNotFoundException(String recordType, String id) {
        super(String.format("No %s was found with ID '%s'.", recordType, id));
    }
}
