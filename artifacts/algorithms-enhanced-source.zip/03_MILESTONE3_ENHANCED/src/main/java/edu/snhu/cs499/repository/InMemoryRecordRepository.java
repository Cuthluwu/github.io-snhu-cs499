package edu.snhu.cs499.repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import edu.snhu.cs499.exception.DuplicateRecordException;
import edu.snhu.cs499.exception.RecordNotFoundException;

/**
 * HashMap-backed repository that provides consistent duplicate and missing-ID
 * behavior for the service layer.
 */
public final class InMemoryRecordRepository<T> implements RecordRepository<T> {
    private final Map<String, T> records = new HashMap<>();
    private final String recordType;

    public InMemoryRecordRepository(String recordType) {
        this.recordType = Objects.requireNonNull(recordType, "recordType cannot be null");
    }

    @Override
    public void add(String id, T record) {
        Objects.requireNonNull(id, "id cannot be null");
        Objects.requireNonNull(record, "record cannot be null");
        if (records.containsKey(id)) {
            throw new DuplicateRecordException(recordType, id);
        }
        records.put(id, record);
    }

    @Override
    public T getRequired(String id) {
        Objects.requireNonNull(id, "id cannot be null");
        T record = records.get(id);
        if (record == null) {
            throw new RecordNotFoundException(recordType, id);
        }
        return record;
    }

    @Override
    public void delete(String id) {
        getRequired(id);
        records.remove(id);
    }

    @Override
    public int size() {
        return records.size();
    }

    @Override
    public List<T> snapshot() {
        return List.copyOf(records.values());
    }
}
