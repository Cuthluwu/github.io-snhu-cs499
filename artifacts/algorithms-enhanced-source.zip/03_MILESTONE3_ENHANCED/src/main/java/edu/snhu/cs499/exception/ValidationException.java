package edu.snhu.cs499.exception;

/**
 * Indicates that a value does not satisfy a domain validation rule.
 */
public final class ValidationException extends IllegalArgumentException {
    private static final long serialVersionUID = 1L;

    public ValidationException(String message) {
        super(message);
    }
}
