package edu.snhu.cs499.model;

import java.util.Objects;

import edu.snhu.cs499.validation.ValidationRules;

/**
 * Represents one contact. The identifier is immutable, while editable fields
 * remain protected by the same validation rules during creation and updates.
 */
public final class Contact {
    public static final int MAX_ID_LENGTH = 10;
    public static final int MAX_NAME_LENGTH = 10;
    public static final int MAX_ADDRESS_LENGTH = 30;

    private final String contactId;
    private String firstName;
    private String lastName;
    private String phone;
    private String address;

    public Contact(String contactId, String firstName, String lastName, String phone, String address) {
        this.contactId = ValidationRules.requiredText(contactId, "Contact ID", MAX_ID_LENGTH);
        this.firstName = ValidationRules.requiredText(firstName, "First name", MAX_NAME_LENGTH);
        this.lastName = ValidationRules.requiredText(lastName, "Last name", MAX_NAME_LENGTH);
        this.phone = ValidationRules.tenDigitPhone(phone, "Phone number");
        this.address = ValidationRules.requiredText(address, "Address", MAX_ADDRESS_LENGTH);
    }

    public String getContactId() {
        return contactId;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getPhone() {
        return phone;
    }

    public String getAddress() {
        return address;
    }

    public void setFirstName(String firstName) {
        this.firstName = ValidationRules.requiredText(firstName, "First name", MAX_NAME_LENGTH);
    }

    public void setLastName(String lastName) {
        this.lastName = ValidationRules.requiredText(lastName, "Last name", MAX_NAME_LENGTH);
    }

    public void setPhone(String phone) {
        this.phone = ValidationRules.tenDigitPhone(phone, "Phone number");
    }

    public void setAddress(String address) {
        this.address = ValidationRules.requiredText(address, "Address", MAX_ADDRESS_LENGTH);
    }

    /**
     * Creates a separate contact instance for safe transfer across a service
     * boundary.
     */
    public Contact copy() {
        return new Contact(contactId, firstName, lastName, phone, address);
    }

    @Override
    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof Contact contact)) {
            return false;
        }
        return contactId.equals(contact.contactId)
                && firstName.equals(contact.firstName)
                && lastName.equals(contact.lastName)
                && phone.equals(contact.phone)
                && address.equals(contact.address);
    }

    @Override
    public int hashCode() {
        return Objects.hash(contactId, firstName, lastName, phone, address);
    }

    @Override
    public String toString() {
        return "Contact{id='" + contactId + "', firstName='" + firstName
                + "', lastName='" + lastName + "'}";
    }
}
