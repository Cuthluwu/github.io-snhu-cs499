# Milestone Three Change Log

## Added for algorithms and data structures

- General case-insensitive contact search across five fields
- Focused last-name contact search
- Case-insensitive task search across name and description
- Inclusive appointment date-range filtering
- Stable comparators with ID tie-breakers
- Validation for search terms and date ranges
- Explicit loop-based scan, match, copy, sort, and return steps
- JUnit cases for ordering, boundaries, empty data, no matches, invalid input, defensive copies, and unmodifiable results
- Dependency-free smoke test for computers without Maven
- Complexity and trade-off analysis

## Corrected while testing

`Appointment.copy()` previously recreated an appointment through the public constructor. That caused a valid stored appointment to become unreadable after its scheduled date passed. The enhanced version uses a private copy constructor that copies already-validated state without rerunning creation-time future-date validation.

## Kept on purpose

- HashMap-backed storage for average O(1) ID operations
- Existing model requirements and length rules
- Repository and validation structure from the software design enhancement
