# CS 499 Milestone Three: Algorithms and Data Structures

## What this project is

This is the enhanced version of my CS 320 Contact, Task, and Appointment service project. The original project supported exact-ID CRUD operations. Milestone Three adds the operations a caller would need when the ID is not known: contact search, task search, appointment date-range filtering, and predictable result ordering.

## Main algorithm changes

- `ContactService.searchContacts()` scans ID, first name, last name, phone, and address.
- `ContactService.searchByLastName()` performs a focused last-name substring search.
- `TaskService.searchTasks()` scans task name and description.
- `AppointmentService.findAppointmentsBetween()` performs inclusive date-range filtering.
- `RecordComparators` defines a stable sort order for each record type.
- Search and filtering return defensive copies in unmodifiable lists.
- `ValidationRules` rejects null or blank search terms and reversed date ranges.
- `Appointment.copy()` was corrected so an appointment remains readable after its scheduled time has passed.

I used explicit loops and `ArrayList` result collections so the scan, match, copy, sort, and return steps are visible in the code instead of being hidden in one stream expression.

## Data-structure decision

The repository remains backed by a `HashMap<String, T>`. Exact-ID add, get, and delete operations are O(1) on average. Searches by other fields require an O(n) scan because those fields are not indexed. If m records match, sorting those matches costs O(m log m) and the returned defensive copies use O(m) additional space.

I kept the HashMap because changing it to a TreeMap would only sort IDs. It would not provide the three different orders required here: contact name, task name, and appointment date.

## Important paths

```text
src/main/java/edu/snhu/cs499/
  algorithm/RecordComparators.java
  service/ContactService.java
  service/TaskService.java
  service/AppointmentService.java
  validation/ValidationRules.java

src/test/java/edu/snhu/cs499/service/
  ContactServiceTest.java
  TaskServiceTest.java
  AppointmentServiceTest.java

src/testSupport/java/edu/snhu/cs499/
  AlgorithmEnhancementSmokeTest.java
  model/AppointmentCopySmokeTest.java
```

The exact method and line locations are listed in `../04_EVIDENCE/ENHANCEMENT_MAP.txt`.

## Verification

From the ZIP root:

- Windows: `VERIFY_WINDOWS.bat`
- Linux/macOS: `./VERIFY_LINUX_MAC.sh`

With Maven installed, the JUnit 5 suite can also be run from this folder with:

```text
mvn test
```
