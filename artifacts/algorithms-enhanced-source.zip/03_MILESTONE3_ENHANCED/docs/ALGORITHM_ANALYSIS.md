# Algorithm and Data-Structure Analysis

## Existing structure

Each service stores records through `InMemoryRecordRepository<T>`, which uses a `HashMap<String, T>`. The unique ID is the key.

| Operation | Average time | Reason |
|---|---:|---|
| Add by ID | O(1) | Hash lookup checks for a duplicate and inserts by key. |
| Get by ID | O(1) | The key points directly to the record. |
| Delete by ID | O(1) | The repository removes the matching key. |
| Count | O(1) | `HashMap.size()` does not scan the records. |

The HashMap is still the correct primary structure because exact ID operations are the original and most precise access path.

## New search and filtering work

The HashMap is not indexed by last name, task text, or appointment date. The broader operations therefore scan the repository snapshot one record at a time.

| Method | Scan | Sort | Extra result space | Total time |
|---|---:|---:|---:|---:|
| `searchContacts` | O(n) | O(m log m) | O(m) | O(n + m log m) |
| `searchByLastName` | O(n) | O(m log m) | O(m) | O(n + m log m) |
| `searchTasks` | O(n) | O(m log m) | O(m) | O(n + m log m) |
| `findAppointmentsBetween` | O(n) | O(m log m) | O(m) | O(n + m log m) |

`n` is the number of stored records. `m` is the number of matches and cannot be larger than `n`.

Each method follows the same visible sequence:

1. Validate and normalize the criteria.
2. Scan the repository snapshot.
3. Add a defensive copy of each match to an `ArrayList`.
4. Sort only the matching records.
5. Return `List.copyOf(matches)` so the caller cannot change the list structure.

## Why the results are sorted

HashMap iteration order is not a user-facing order and is not guaranteed. The comparator rules are:

- Contacts: last name, first name, then contact ID
- Tasks: task name, then task ID
- Appointments: date, then appointment ID

The ID is the final tie-breaker. Without it, equal names or equal dates could produce an inconsistent order and unstable tests.

## Alternatives I considered

### TreeMap

A TreeMap would make ID operations O(log n) and keep IDs ordered. That does not solve this project because the required result orders are based on last name, task name, and appointment date rather than ID.

### Separate secondary indexes

A map for each searchable field could reduce repeated scans. It would also create more state to keep synchronized every time a record is added, updated, or deleted. That extra maintenance is not justified for this small in-memory project.

### Database indexing

For a large or persistent system, the better next step would be database indexes and query operations. The current artifact is deliberately small and in memory, so a linear scan with sorted matches is easier to verify and less likely to become inconsistent.

## Final choice

The final design keeps the fast ID path and adds broader algorithms only when the caller needs them. It is not the fastest possible design for a very large dataset, but it fits the size and purpose of this artifact, keeps the behavior easy to test, and makes the trade-off explicit.
