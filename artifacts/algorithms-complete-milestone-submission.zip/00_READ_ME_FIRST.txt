CS 499 MILESTONE THREE - ALGORITHMS AND DATA STRUCTURES
Student: Madison Parker

This ZIP is intentionally simple. It opens directly to this file and four numbered folders.
There is no ZIP inside this ZIP.

WHAT TO OPEN FIRST
1. 04_EVIDENCE/ENHANCEMENT_MAP.txt
   This gives the exact file, method, and line range for each claimed enhancement.

2. 03_MILESTONE3_ENHANCED/
   This is the completed Milestone Three project.

3. 04_EVIDENCE/MILESTONE3_CHANGESET.diff
   This is a line-by-line comparison between the pre-Milestone Three baseline and the completed enhancement.

FOLDER PURPOSES
01_ORIGINAL_CS320_CODE
- Original CS 320 artifact before CS 499 changes.

02_BASELINE_BEFORE_MILESTONE3
- The project after the software design enhancement and immediately before the algorithm enhancement.

03_MILESTONE3_ENHANCED
- The completed algorithm and data-structure enhancement.

04_EVIDENCE
- Enhancement map, rubric crosswalk, complexity analysis, test results, change diff, and file checksums.

QUICK VERIFICATION
Windows: double-click VERIFY_WINDOWS.bat
Linux/macOS: run ./VERIFY_LINUX_MAC.sh

The verification compiles the production code for Java 17 with -Xlint:all, runs the algorithm smoke test, and runs the appointment-copy regression test.
