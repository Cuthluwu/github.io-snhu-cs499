@echo off
setlocal
cd /d "%~dp0"
set "PROJECT=03_MILESTONE3_ENHANCED"
set "BUILD=%PROJECT%\build"

where javac >nul 2>nul
if errorlevel 1 (
  echo Java JDK was not found. Install Java 17 or newer and try again.
  exit /b 1
)

if exist "%BUILD%" rmdir /s /q "%BUILD%"
mkdir "%BUILD%\main"
mkdir "%BUILD%\testsupport"

for /r "%PROJECT%\src\main\java" %%F in (*.java) do echo "%%F">> "%BUILD%\main_sources.txt"
javac --release 17 -Xlint:all -d "%BUILD%\main" @"%BUILD%\main_sources.txt"
if errorlevel 1 exit /b 1

for /r "%PROJECT%\src\testSupport\java" %%F in (*.java) do echo "%%F">> "%BUILD%\testsupport_sources.txt"
javac --release 17 -Xlint:all -cp "%BUILD%\main" -d "%BUILD%\testsupport" @"%BUILD%\testsupport_sources.txt"
if errorlevel 1 exit /b 1

java -cp "%BUILD%\main;%BUILD%\testsupport" edu.snhu.cs499.AlgorithmEnhancementSmokeTest
if errorlevel 1 exit /b 1

java -cp "%BUILD%\main;%BUILD%\testsupport" edu.snhu.cs499.model.AppointmentCopySmokeTest
if errorlevel 1 exit /b 1

echo Verification complete: compilation and both dependency-free tests passed.
endlocal
