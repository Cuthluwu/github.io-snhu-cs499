#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
PROJECT="$ROOT/03_MILESTONE3_ENHANCED"
BUILD="$PROJECT/build"

rm -rf "$BUILD"
mkdir -p "$BUILD/main" "$BUILD/testsupport"

find "$PROJECT/src/main/java" -name '*.java' -print0 \
  | xargs -0 javac --release 17 -Xlint:all -d "$BUILD/main"

find "$PROJECT/src/testSupport/java" -name '*.java' -print0 \
  | xargs -0 javac --release 17 -Xlint:all -cp "$BUILD/main" -d "$BUILD/testsupport"

java -cp "$BUILD/main:$BUILD/testsupport" edu.snhu.cs499.AlgorithmEnhancementSmokeTest
java -cp "$BUILD/main:$BUILD/testsupport" edu.snhu.cs499.model.AppointmentCopySmokeTest

echo "Verification complete: compilation and both dependency-free tests passed."
